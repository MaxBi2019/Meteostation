#include "terminal.h"

void TerminalIinit()
{
	while (!USB_CDC_Is_Ready());
}
