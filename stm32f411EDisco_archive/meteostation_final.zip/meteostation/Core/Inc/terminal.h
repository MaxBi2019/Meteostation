#ifndef MAX_TERMINAL_MACROS_N_FUNCTIONS

char str_buf[100];

#include "main.h"
#include "usb_device.h"
#include "usbd_cdc_if.h"
#include "string.h"

void TerminalIinit();

#define print(str) HAL_Delay(1);CDC_Transmit_FS((uint8_t*)str, strlen(str))

#define MAX_TERMINAL_MACROS_N_FUNCTIONS
#endif /*MAX_TERMINAL_MACROS_N_FUNCTIONS*/
