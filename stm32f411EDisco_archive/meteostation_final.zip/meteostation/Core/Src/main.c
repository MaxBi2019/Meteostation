/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under Ultimate Liberty license
  * SLA0044, the "License"; You may not use this file except in compliance with
  * the License. You may obtain a copy of the License at:
  *                             www.st.com/SLA0044
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "fatfs.h"
#include "i2c.h"
#include "i2s.h"
#include "spi.h"
#include "tim.h"
#include "usart.h"
#include "usb_device.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
//#include "terminal.h"
#include "logger.h"
#include "usbd_cdc_if.h" /* 30 */
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "BME280.h"
#include "SimpleRTC.h"
#include "display.h"
#include "m_config.h"
#include "CO2.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

typedef struct
{
	float temperature[NUMBER_OF_INTERVALS];
	float preasure[NUMBER_OF_INTERVALS];
	float humidity[NUMBER_OF_INTERVALS];
	uint16_t co2[NUMBER_OF_INTERVALS];

	float prev_temperature;
	float prev_preasure;
	float prev_humidity;
	uint16_t prev_co2;

	uint8_t index;
	uint8_t	no_prev;
} analysis;


analysis meas_analysis = {
		.index   = 0,
		.no_prev = TRUE
};

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

volatile uint8_t time_to_write = FALSE;

uint16_t volatile counter_r;
uint16_t volatile counter_m;
uint16_t volatile counter_t;
uint16_t volatile counter_d;
uint16_t volatile counter_i;


/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

I2C_HandleTypeDef hi2c1;






volatile size_t off_time;
volatile size_t last_on;
volatile size_t off_interval;
volatile size_t update_time;
volatile size_t	start_wait;



//#define SET___DATE




/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
void display_measurements_update();
void display_delta_update();
void display_time_update();
void display_sd_update();
void fill();
float mean(float *arr);
void update();

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */


/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_I2C1_Init();
  MX_I2S2_Init();
  MX_I2S3_Init();
  MX_SPI1_Init();
  MX_USB_DEVICE_Init();
  MX_USART1_UART_Init();
  MX_TIM10_Init();
  MX_SPI5_Init();
  MX_FATFS_Init();
  MX_USART2_UART_Init();
  /* USER CODE BEGIN 2 */


  Logger_Init();
  CO2Init();
  BME280_Init();
  ds3231_driver.innit(&hi2c1);

  display->init(10);

  display_sd_update();
  display_delta_update();
  display_measurements_update();
  display_time_update();



  #ifdef SET___DATE
  ds3231_driver.setter.date = 17;
  ds3231_driver.setter.day_of_week = 0;
  ds3231_driver.setter.hours = 11;
  ds3231_driver.setter.is_12hr_mode = MOD_12_HOUR;
  ds3231_driver.setter.is_PM = IS_PM;
  ds3231_driver.setter.minutes = 21;
  ds3231_driver.setter.seconds = 0;
  ds3231_driver.setter.month = 1;
  ds3231_driver.setter.year = 2021;
  ds3231_driver.set_time();
  #endif



  display -> display = TIME_SCREEN;
  display -> update_frame();

  HAL_TIM_Base_Start_IT(&htim10);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
	  if (time_to_write)
	  {
		  time_to_write = FALSE;
		  write_logs(sdinfo.str);
	  }
	  __disable_irq();
	  update();
	  __enable_irq();
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 192;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
  RCC_OscInitStruct.PLL.PLLQ = 8;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInitStruct.PeriphClockSelection = RCC_PERIPHCLK_I2S;
  PeriphClkInitStruct.PLLI2S.PLLI2SN = 200;
  PeriphClkInitStruct.PLLI2S.PLLI2SM = 5;
  PeriphClkInitStruct.PLLI2S.PLLI2SR = 2;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	__disable_irq();
		if (counter_r <=  CO2_START_TIME)
			++counter_r;

		if (++counter_t == UPDATE_TIME)
		{
			display_time_update();
			counter_t ^= counter_t;
		}


		if (++counter_m == UPDATE_MEASURMENTS)
		{
			display_measurements_update();
			counter_m ^= counter_m;
		}

		if (++counter_i == UPDATE_INTERVAL)
		{
			fill();
			counter_i ^= counter_i;
			meas_analysis.index++;
		}

		if (++counter_d == UPDATE_DELTA)
		{
			display_delta_update();
			counter_d ^= counter_d;
			meas_analysis.index = 0;
		}
		display -> update_frame();
	__enable_irq();
}


void fill()
{
	BME280_COLLECT();
	meas_analysis.humidity[meas_analysis.index] = bme_280_d.hmdt_f;
	meas_analysis.preasure[meas_analysis.index] = bme_280_d.prsr_f;
	meas_analysis.temperature[meas_analysis.index] = bme_280_d.tmpr_f;
	meas_analysis.co2[meas_analysis.index] = CO2Collect();
}


void update()
{
	if (HAL_GPIO_ReadPin(BUTTON_GPIO_Port, BUTTON_Pin))
		last_on = HAL_GetTick();
	else
		off_time = HAL_GetTick() - last_on;

}


void  HAL_GPIO_EXTI_Callback(uint16_t PIN)
{
	if (PIN != BUTTON_Pin)
		return;

	__disable_irq();
	update();
	if (OFF_MIN > off_time)
		return;

	off_time = 0;
	update();

	display -> display = (display -> display + 1)% SCREEN_NUMBER;

	display -> update_frame();
	__enable_irq();
}



double meanf(float *arr)
{
	double mean = 0;
	for (int index = meas_analysis.index-1; index >= 0; --index)
	{
		mean += arr[index];
	}
	return mean/meas_analysis.index;
}

double meani(uint16_t *arr)
{
	uint16_t mean = 0;
	for (int index = meas_analysis.index-1; index >= 0; --index)
	{
		mean += arr[index];
	}
	return mean/meas_analysis.index;
}


void display_delta_update()
{
	double dp;
	double dh;
	double dt;
	double dc;

	char preasure[50];
	char temperature[50];
	char humidity[50];
	char co2[50];

	if (meas_analysis.no_prev)
	{
		display -> edit_frame(data_screen, UPDATE_DELTA, "?", "?", "?", "?");
		if (counter_r > CO2_START_TIME)
		{
			co2_is_ready=1;
			meas_analysis.no_prev = 0;
		}
	}
	else
	{
		dp = meanf(meas_analysis.preasure)    - meas_analysis.prev_preasure;
		dh = meanf(meas_analysis.humidity)    - meas_analysis.prev_humidity;
		dt = meanf(meas_analysis.temperature) - meas_analysis.prev_temperature;
		dc = meani(meas_analysis.co2) - meas_analysis.prev_co2;


		sprintf(preasure,    "%.5s%lf", (dp > 0)? "+ ": "- ", fabs(dp));
		sprintf(temperature, "%.5s%lf", (dh > 0)? "+ ": "- ", fabs(dh));
		sprintf(humidity,    "%.5s%lf", (dt > 0)? "+ ": "- ", fabs(dt));
		sprintf(co2,         "%.5s%lf", (dc > 0)? "+ ": "- ", fabs(dc));

		display -> edit_frame(data_screen, UPDATE_DELTA, preasure, temperature, humidity, co2);
		time_to_write = TRUE;
		sprintf(sdinfo.str, "%.4s%.2s%.2sT%.2s%.2s,%lf,%lf,%lf,%lf\n",
				             ds3231_driver.getter.date_str+10,
							 ds3231_driver.getter.date_str+7,
							 ds3231_driver.getter.date_str+4,
							 ds3231_driver.getter.time_str,
							 ds3231_driver.getter.time_str+3,
							 meanf(meas_analysis.preasure),
							 meanf(meas_analysis.humidity),
							 meanf(meas_analysis.temperature),
							 meani(meas_analysis.co2));
		display -> edit_frame(data_screen, UPDATE_DELTA, preasure, temperature, humidity, co2);

	}
	meas_analysis.prev_humidity = meanf(meas_analysis.humidity);
	meas_analysis.prev_preasure = meanf(meas_analysis.preasure);
	meas_analysis.prev_temperature = meanf(meas_analysis.temperature);
	meas_analysis.prev_co2 = meani(meas_analysis.co2);
}



void display_measurements_update()
{
	char co2[30];
	if (co2_is_ready)
		sprintf(co2, "C: %u ppm\n", CO2Collect());
	else
		sprintf(co2, "C: NAN\n");
	BME280_COLLECT();
	display -> edit_frame(measurements_screen, bme_280_d.prsr_s, bme_280_d.hmdt_s,  bme_280_d.tmpr_s, co2);
}



void display_time_update()
{
	ds3231_driver.get_time();
	display -> edit_frame(time_screen, ds3231_driver.getter.time_str, ds3231_driver.getter.date_str);
}


void display_sd_update()
{
	display -> edit_frame(sd_screen, (sdinfo.is_init && sdinfo.is_compatible)?"+": "-");
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */

  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
