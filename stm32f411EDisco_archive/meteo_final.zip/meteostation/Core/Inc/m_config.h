
#define UPDATE_TIME         1
#define UPDATE_MEASURMENTS  5
#define UPDATE_DELTA	    60


#define CO2_START_TIME		180 // 3 minutes
#define OFF_MIN			    100
#define NUMBER_OF_INTERVALS 10
#define UPDATE_INTERVAL	    UPDATE_DELTA/NUMBER_OF_INTERVALS
