#include "main.h"
#include "terminal.h"
#include "usart.h"

extern uint8_t co2_is_ready;
uint16_t CO2Collect();
void CO2Init();
