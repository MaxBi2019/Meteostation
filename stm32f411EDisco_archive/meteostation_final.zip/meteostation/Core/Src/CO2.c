#include "CO2.h"

uint8_t co2_is_ready = 0;

static uint8_t tx_array[9] = {0xFF,0x01,0x86,0x00,0x00,0x00,0x00,0x00,0x79};
static uint8_t rx_array[9] = {0x00};

void CO2Init()
{
	CO2Collect();
}


uint16_t CO2Collect()
{
  	HAL_UART_Transmit(&huart2, tx_array, 9, 0xffff);
  	HAL_UART_Receive(&huart2, rx_array, 9, 0xffff);
  	uint16_t co2_value = 0;
  	if (rx_array[1] == 0x86)
  	{
  	    co2_value = (uint16_t)rx_array[2]*256 + (uint16_t)rx_array[3];
  	}
  	else
  	{
  	    co2_value = 0;
  	}
  	return  co2_value;
}
